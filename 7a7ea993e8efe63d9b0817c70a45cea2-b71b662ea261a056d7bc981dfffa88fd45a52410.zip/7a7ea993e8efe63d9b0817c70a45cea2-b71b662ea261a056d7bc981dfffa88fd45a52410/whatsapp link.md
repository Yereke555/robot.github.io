```html
<a href="https://api.whatsapp.com/send?phone=15551234567">Send Message</a>

<a href="whatsapp://send?abid=phonenumber&text=Hello%2C%20World!">whatsapp</a>

<a href="intent://send/phonenumber#Intent;scheme=smsto;package=com.whatsapp;action=android.intent.action.SENDTO;end">test</a>